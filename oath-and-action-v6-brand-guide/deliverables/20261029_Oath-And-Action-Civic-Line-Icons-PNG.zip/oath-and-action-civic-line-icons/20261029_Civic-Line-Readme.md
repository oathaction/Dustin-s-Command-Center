# Oath & Action Civic Line icons

Released on October 29, 2026, after Dustin Cathcart approved the set (DR-07) and its variants (DR-08 to DR-10). The package comes as two archives that unpack into the same folder: the SVG archive holds the vectors, the catalog page and the data files, and the PNG archive holds the rasters and the reference crops. Each carries this readme.

## What the package holds

- Four bare editions of all 122 icons: `red-black/`, `black/`, `red-newsprint/` and `newsprint/`, 488 SVGs, with transparent PNGs at 256 and 512 px in `png-256/` and `png-512/` (976 PNGs).
- Tiles: twelve per icon in `tiles/<shape>-<tile>/`, each with `svg/`, `png-256/` and `png-512/` (1,464 SVGs and 2,928 PNGs).
- `contact-sheets/`: the five catalog sheets in all four editions, as SVG, PNG and 2x PNG, and `contact-sheets/tiles/`: twelve overview sheets with all 122 tiles of each kind.
- `reference-crops/`: 244 untouched crops of the supplied reference sheets.
- `20261029_Civic-Line-Icon-Catalog.html`: a searchable page with every icon, edition and tile.
- The inventory (`20261029_Civic-Line-Inventory.json` and `.csv`), the fidelity measurements (`20261029_Civic-Line-Fidelity-Metrics.csv`) and the contrast table (`20261029_Civic-Line-Contrast-Table.md`).

## The four editions

| Edition | Lines | Accent | Ground it is drawn for |
|---|---|---|---|
| Red-black | Charcoal #121212 | Pillar Red #E63946 | Newsprint #DCD9D2 and White |
| Black | Charcoal #121212 | Charcoal | Newsprint, White and any light ground |
| Red-newsprint | Newsprint #DCD9D2 | Pillar Red #E63946 | Charcoal |
| Newsprint | Newsprint #DCD9D2 | Newsprint | Charcoal and Prussian #1F2D5A, where red never sits |

Each edition is the red-black file with its ink colors swapped, so all four share every coordinate. A script parsed every file: the four editions of each icon share the same elements and attributes apart from ink color and the root of each id, and every tile holds its bare export's geometry under one transform per icon, with its strokes held at the set's heaviest line. No id repeats across the 1,985 SVG files. Inside each SVG the main drawing sits in the group marked `data-part="base"` and the colored parts in the group marked `data-part="accent"`; in a tile the shape carries `data-part="tile"` and the icon group `data-part="icon"`. Every id inside a file starts with that file's root id, such as `oa-civic-line-cl-057-red-black` or `oa-civic-line-cl-057-tile-rounded-charcoal-two-color`, so any number of files can be inlined on one page, hidden or shown, without one file's mask reaching into another.

## Size, scale and stroke

Every bare file has a transparent background and a 128 by 128 viewBox. Each icon grows toward 116 of the 128 units by at most 1.25 times the set's shared scale of 0.487395 units per source pixel (DR-08), so strokes run from 2.68 to 3.35 units and every icon sits centered on its own drawing.

The icons read best from 48 px up. At 24 px the stroke is half a pixel wide (0.50 to 0.63 px), and at 32 px 0.67 to 0.84 px, so fine details soften. Use below 32 px would need its own small-size drawings.

## Tiles

Each icon comes in a square, a rounded square and a circle (DR-10). The rounded square is the superellipse |x|^5 + |y|^5 = 1 drawn with 96 cubic curves whose curvature runs on without a step at every join, the continuous corner of an app icon rather than a plain rounded corner. A Charcoal tile carries the Newsprint editions and a Newsprint tile the Charcoal editions, each in two-color and one-color. Names end in `-Tile-<Shape>-<Tile>-Two-Color` or `-One-Color`.

In a tile the bare icon scales about the center by 0.68 (square), 0.66 (rounded) or 0.62 (circle), chosen on a calibration board of twenty varied icons at 96 and 192 px; the 48 px rows sit below the tile minimum and are kept for reference. Measured against the side of a square with the tile's area, the icon spans 0.680 of the square, 0.677 of the rounded square and 0.700 of the circle, whose edge closes in at the corners, so the three shapes hold one icon size.

On top of the shape factor, 36 icons carry an optical scale between 0.94 and 1.09: the dense, squarish drawings come down a little and the compact or thin ones go up, and the four pillar marks are set as one group so they read as equals in a row. Where the larger size would make a line heavier than the set's heaviest stroke, every stroke width in that tile is multiplied down to 3.35 units, so tile lines run from 2.73 to 3.35 units. 8 icons whose subject is heavy on one side (CL-010, CL-013, CL-049, CL-051, CL-071, R-07, R-08 and R-11) move 1.5 to 2.5 units toward their light side in the rounded tile, and in proportion in the other two. The inventory records each icon's optical scale (`tile_optical_scale`), offset (`tile_offset_x`), scale per shape (`tile_scale`) and line weight in the tile (`tile_stroke_units`). The bare editions stay centered on their ink box. Every icon keeps a clear margin from every tile edge; the smallest are 21.5 units on the square (R-44), 22.7 on the rounded square (R-44) and 21.9 on the circle (CL-051), out of 128.

### Minimum tile sizes

A tile shrinks its icon, so each tile has a smallest size, recorded per icon in the inventory as `tile_min_px`:

| Tile | Square | Rounded | Circle |
|---|---:|---:|---:|
| One-color, the 94 icons that read at 32 px bare | 48 px | 52 px | 52 px |
| One-color, the 28 icons that need 48 px bare | 72 px | 76 px | 80 px |
| Two-color, all 122 icons | 72 px | 76 px | 80 px |

Each minimum is the bare icon's floor (32 px, or 48 px for the 28 icons listed in the inventory) divided by the shape factor and rounded up to a multiple of 4 px; a two-color tile takes the 48 px floor for every icon, so its Pillar Red reaches its true value. At the two-color minimum the line is 1.28 to 1.31 px for the icons at the set's full stroke, and 1.04 px at the least (R-47, whose tile line is the thinnest in the set).

### Using the tiles

- A two-color tile is for an icon that stands alone: an app tile, an avatar or a single feature icon. In a row or a menu, use one-color tiles and give the red to the current item only (rule 05.3, D2-01).
- A Newsprint tile on a White page has a soft edge (1.41:1). On White, use the Charcoal tile or a bare red-black or black icon.
- For an iOS or Android app icon, supply the square tile at full bleed and let the platform apply its own corner. Never submit the rounded or circle tile, which would round the corner twice. The square tile PNGs carry an alpha channel today; the App Store's icon size and alpha rules and Android's adaptive-icon safe zone get checked on the platforms' own pages in the applications phase (Master Brief section 18).

## Contrast

Charcoal and Newsprint lines meet their grounds at 13.29:1. Pillar Red meets Charcoal at 4.49:1 and White at 4.17:1. On Newsprint it measures 2.96:1, under the 3:1 guideline for graphics, so on the red-black edition and the Newsprint two-color tiles the red adds emphasis to a shape that the one-color editions also carry. The full table is in `20261029_Civic-Line-Contrast-Table.md`.

## Traced reconstructions and reference crops

The SVGs are traced reconstructions. Each was drawn as clean vector geometry over its reference and measured against it, with one line weight across the set and true circles and straight lines where the drawing means them (DR-03). They are not pixel copies of the sheets. The fidelity table records each trace's silhouette overlap with its reference (median 0.924, where 1 means identical), the overlap of the red parts (median 0.896) and how far its edges sit from the reference's (median of the per-icon means 0.20 source pixels).

The reference crops are untouched source pixels: exact copies of each icon's rectangle on the supplied sheets, kept for comparison.

## R-35

R-35 is named "Term Limits · Rejected". It records an option the atlas rejected, and it keeps that name in its file names, the inventory, the sheets and the catalog.

## Contact sheets

The contact sheets repeat the layout of the supplied sheets cell for cell, with the traced icons in place of the raster ones and the approved Edition 06 wordmark (DR-05). All 32 sheets share one header and footer: the wordmark, a rule from x = 49 to 1487, and the title and footer set flush right at x = 1487. The captions in each row share one baseline. Their text is set in Inter and converted to outlines, so no font files are needed.

## Rights

Dustin Cathcart supplied the ten Civic Line reference sheets. The studio traced them into these vector masters under decision DR-02, which grants an exception to the brief's rule on reference images for these sheets only. Inter is licensed under the SIL Open Font License 1.1; the package contains no font files.
