# Oath & Action Civic Line icons

Released on October 29, 2026, after Dustin Cathcart approved the set (DR-07) and its variants (DR-08 to DR-10). The package comes as two archives that unpack into the same folder: the SVG archive holds the vectors, the catalog page and the data files, and the PNG archive holds the rasters and the reference crops. Each carries this readme.

## What the package holds

- Four bare editions of all 122 icons: `red-black/`, `black/`, `red-newsprint/` and `newsprint/`, 488 SVGs, with transparent PNGs at 256 and 512 px in `png-256/` and `png-512/` (976 PNGs).
- Tiles: twelve per icon in `tiles/<shape>-<tile>/`, each with `svg/`, `png-256/` and `png-512/` (1,464 SVGs and 2,928 PNGs).
- `contact-sheets/`: the five catalogue sheets in all four editions, as SVG, PNG and 2x PNG, and `contact-sheets/tiles/`: twelve overview sheets with all 122 tiles of each kind.
- `reference-crops/`: 244 untouched crops of the supplied reference sheets.
- `20261029_Civic-Line-Icon-Catalog.html`: a searchable page with every icon, edition and tile.
- The inventory (`20261029_Civic-Line-Inventory.json` and `.csv`), the fidelity measurements (`20261029_Civic-Line-Fidelity-Metrics.csv`) and the contrast table (`20261029_Civic-Line-Contrast-Table.md`).

## The four editions

| Edition | Lines | Accent | Ground it is drawn for |
|---|---|---|---|
| Red-black | Charcoal #121212 | Pillar Red #E63946 | Newsprint #DCD9D2 and White |
| Black | Charcoal #121212 | Charcoal | Newsprint, White and any light ground |
| Red-newsprint | Newsprint #DCD9D2 | Pillar Red #E63946 | Charcoal |
| Newsprint | Newsprint #DCD9D2 | Newsprint | Charcoal and Prussian #1F2D5A, where red never sits |

Each edition is the red-black file with its ink colours swapped, so all four share every coordinate. A script parsed every file: the four editions of each icon share the same elements and attributes apart from ink color, and every tile holds its bare export's geometry unchanged under one transform. Inside each SVG the main drawing sits in the group `base` and the coloured parts in the group `accent`.

## Size, scale and stroke

Every bare file has a transparent background and a 128 by 128 viewBox. Each icon grows toward 116 of the 128 units by at most 1.25 times the set's shared scale of 0.487395 units per source pixel (DR-08), so strokes run from 2.68 to 3.35 units and every icon sits centred on its own drawing.

The icons read best from 48 px up. At 24 px the stroke is half a pixel wide (0.50 to 0.63 px), and at 32 px 0.67 to 0.84 px, so fine details soften. Use below 32 px would need its own small-size drawings.

## Tiles

Each icon comes in a square, a rounded square and a circle (DR-10). The rounded square is the superellipse |x|^5 + |y|^5 = 1 drawn with 96 cubic curves whose curvature runs on without a step at every join, the continuous corner of an app icon rather than a plain rounded corner. A Charcoal tile carries the Newsprint editions and a Newsprint tile the Charcoal editions, each in two-color and one-color. Names end in `-Tile-<Shape>-<Tile>-Two-Color` or `-One-Color`.

In a tile the bare icon scales about the centre by 0.68 (square), 0.66 (rounded) or 0.62 (circle), chosen on a calibration board of twenty varied icons at 48, 96 and 192 px. One factor per shape keeps the line weights within the set's 25 percent spread. Every icon keeps a clear margin from every tile edge; the smallest are 23.6 units on the square (R-46), 24.8 on the rounded square (R-46) and 20.3 on the circle (CL-059), out of 128.

## Contrast

Charcoal and Newsprint lines meet their grounds at 13.29:1. Pillar Red meets Charcoal at 4.49:1 and White at 4.17:1. On Newsprint it measures 2.96:1, under the 3:1 guideline for graphics, so on the red-black edition and the Newsprint two-color tiles the red adds emphasis to a shape that the one-color editions also carry. The full table is in `20261029_Civic-Line-Contrast-Table.md`.

## Traced reconstructions and reference crops

The SVGs are traced reconstructions. Each was drawn as clean vector geometry over its reference and measured against it, with one line weight across the set and true circles and straight lines where the drawing means them (DR-03). They are not pixel copies of the sheets. The fidelity table records each trace's silhouette overlap with its reference (median 0.924, where 1 means identical), the overlap of the red parts (median 0.896) and how far its edges sit from the reference's (median of the per-icon means 0.20 source pixels).

The reference crops are untouched source pixels: exact copies of each icon's rectangle on the supplied sheets, kept for comparison.

## R-35

R-35 is named "Term Limits · Rejected". It records an option the atlas rejected, and it keeps that name in its file names, the inventory, the sheets and the catalog.

## Contact sheets

The contact sheets repeat the layout of the supplied sheets cell for cell, with the traced icons in place of the raster ones and the approved Edition 06 wordmark (DR-05). Their text is set in Inter and converted to outlines, so no font files are needed.

## Rights

Dustin Cathcart supplied the ten Civic Line reference sheets. The studio traced them into these vector masters under decision DR-02, which grants an exception to the brief's rule on reference images for these sheets only. Inter is licensed under the SIL Open Font License 1.1; the package contains no font files.
