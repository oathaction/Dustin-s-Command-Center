# Oath & Action Civic Line icons: review package

Prepared on October 29, 2026 for Dustin Cathcart's review. This is a review copy. It moves to `deliverables/` once Dustin approves it.

## What the package holds

- `red-black/` and `black/`: 122 SVG masters in each edition, 244 in all.
- `png-256/` and `png-512/`: transparent PNGs of every SVG at 256 and 512 px, each with `red-black/` and `black/` folders, 488 in all.
- `contact-sheets/`: the five catalogue sheets in both editions, each as SVG, PNG and a 2x PNG.
- `reference-crops/`: 244 untouched crops of the supplied reference sheets, one from the black sheet and one from the red sheet per icon.
- `20261029_Civic-Line-Inventory.json` and `.csv`: one row per icon with its ID, name, sheet, row, column, crop rectangle, file names and status.
- `20261029_Civic-Line-Fidelity-Metrics.csv`: the measurements of each trace against its reference.

## The two editions

The red-black edition draws each icon in Charcoal (#121212) and the parts the catalogue names in Pillar Red (#E63946). It is drawn for Newsprint (#DCD9D2) and White grounds. The black edition draws every part in Charcoal. Each black file is its red-black file with Pillar Red swapped for Charcoal, so the two share every coordinate. A script parsed all 122 pairs and found the same elements and attributes in each, with colour as the only difference.

Inside each SVG the main drawing sits in a group with the id `base` and the coloured parts in a group with the id `accent`.

## Size, scale and stroke

Every file has a transparent background. The SVGs contain no background shape, and the PNGs are transparent outside the drawing.

Every SVG uses a 128 by 128 viewBox with one stroke width of 2.68 units, measured from the sheets as 5.5 source pixels. One scale serves the whole set, 0.487395 units per source pixel, so each icon keeps its size relative to the others, as on the sheets. The widest icon, R-44, spans 116 units, and each icon is centred on its own drawing.

The icons read best from 48 px up. At 24 px the stroke is half a pixel wide (0.50 px), and at 32 px it is 0.67 px, so fine details soften. Use below 32 px would need its own small-size drawings.

## Traced reconstructions and reference crops

The SVGs are traced reconstructions. Each was drawn as clean vector geometry over its reference and measured against it, with one line weight across the set and true circles and straight lines where the drawing means them (decision DR-03). They are not pixel copies of the sheets. The fidelity CSV records each trace's silhouette overlap with its reference (median 0.924, where 1 means identical), the overlap of the red parts (median 0.896) and how far its edges sit from the reference's (median of the per-icon means 0.20 source pixels). Status today: 122 reviewed.

The reference crops are untouched source pixels: exact copies of each icon's rectangle on the supplied sheets, kept for comparison.

## R-35

R-35 is named "Term Limits · Rejected". It records an option the atlas rejected, and it keeps that name in its file names, the inventory and the contact sheets.

## Contact sheets

The contact sheets repeat the layout of the supplied sheets cell for cell, with the traced icons in place of the raster ones. They carry the approved Edition 06 wordmark (decision DR-05). Their text is set in Inter and converted to outlines, so the sheets need no font files.

## Rights

Dustin Cathcart supplied the ten Civic Line reference sheets. The studio traced them into these vector masters under decision DR-02, which grants an exception to the brief's rule on reference images for these sheets only. Inter is licensed under the SIL Open Font License 1.1; the package contains no font files.
